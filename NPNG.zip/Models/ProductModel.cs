﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WebBanHang.Repository.Validation;

namespace WebBanHang.Models
{
	public class ProductModel
	{
		[Key]
		public int Id { get; set; }
		[Required(ErrorMessage="Yeu cau nhap ten San Pham")]
		public string Name { get; set; }
		[Required, MinLength(4, ErrorMessage = "Yeu cau nhap mo ta San Pham")]
		public string Description { get; set; }
        [Range(0.01, 99999999.99, ErrorMessage = "Product Price must be between 0.01 and 99999999.99")]
		public decimal Price { get; set; }
		[Required, Range(1,int.MaxValue,ErrorMessage ="Chon mot thuong hieu")]
		public int BrandId { get; set; }

        [Required, Range(1, int.MaxValue, ErrorMessage = "Chon mot danh muc")]
        public int CategoryId { get; set; }
        public string Slug { get; set; }
		public string Image { get; set; }
		public CategoryModel Category { get; set; }
       
        public BrandModel Brand { get; set; }
		[NotMapped]
		[FileExtension]

        public IFormFile?  ImageUpload {  get; set; }
	}
}
