﻿namespace WebBanHang.Models.ViewModels
{
	public class CartItemViewModel
	{
		public List<CartItemModel> CartItems { get; set; }
		public decimal GrandTotal { get; set; }
		public int Quantity { get; internal set; }
	}
}
