﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace WebBanHang.Models
{
	public class UserModel
	{
		public int Id { get; set; }
		[Required(ErrorMessage="Yêu cầu nhập UserName")]
		public string UserName { get; set; }
		[DataType(DataType.Password),Required(ErrorMessage ="Yêu cầu nhâp Password")]
	
		public string Password { get; set; }
		[Required(ErrorMessage = "Yêu cầu nhập Email"),EmailAddress]
		public string Email { get; set; }

	}
}
