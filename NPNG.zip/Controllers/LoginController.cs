﻿namespace WebBanHang.Controllers
{
	public class LoginController
	{
	}
}
