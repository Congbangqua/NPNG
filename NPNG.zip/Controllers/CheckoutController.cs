﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using WebBanHang.Models;
using WebBanHang.Repository;

namespace WebBanHang.Controllers
{
	public class CheckoutController : Controller
	{
		private readonly DataContext _dataConText;
		public CheckoutController(DataContext context)
		{
			_dataConText = context;
		}
		public async Task<IActionResult> Checkout()
		{
			var userEmail = User.FindFirstValue(ClaimTypes.Email);
			if (userEmail == null)
			{
				return RedirectToAction("Login", "Account");
			}
			else
			{
				var ordercode = Guid.NewGuid().ToString();
				var orderItem = new OrderModel();
				orderItem.OrderCode = ordercode;		
				orderItem.UserName = userEmail;
				orderItem.Status = 1;
				_dataConText.Add(orderItem);
				_dataConText.SaveChanges();
				List<CartItemModel> cartItems = HttpContext.Session.GetJson<List<CartItemModel>>("Cart") ?? new List<CartItemModel>();
				foreach (var cart in cartItems)
				{
					var orderdetails = new OrderDetails();
					orderdetails.UserName = userEmail;
					orderdetails.OrderCode = ordercode;
					orderdetails.ProductId = cart.ProductId;
					orderdetails.Price = cart.Price;
					orderdetails.Quantity = cart.Quantity;
					_dataConText.Add(orderdetails);
					_dataConText.SaveChanges();
				}
				HttpContext.Session.Remove("Cart");
				TempData["success"] = "Sản phầm được dặt thành công";
				return RedirectToAction("Index", "Cart");
			}
			return View();
		}
	}
}
