﻿using Microsoft.AspNetCore.Identity;
using WebBanHang.Models;

namespace WebBanHang.Repository
{
	public class DataSeeder
	{
		private readonly RoleManager<IdentityRole> _roleManager;
		private readonly UserManager<AppUserModel> _userManager;

		public DataSeeder(RoleManager<IdentityRole> roleManager, UserManager<AppUserModel> userManager)
		{
			_roleManager = roleManager;
			_userManager = userManager;
		}

		public async Task SeedRolesAsync()
		{
			var roles = new List<string> { "Admin", "Manager", "User" };

			foreach (var role in roles)
			{
				if (!await _roleManager.RoleExistsAsync(role))
				{
					await _roleManager.CreateAsync(new IdentityRole(role));
				}
			}
		}

		public async Task SeedAdminUserAsync()
		{
			var adminEmail = "admin@example.com";
			var adminPassword = "Admin@123";

			if (await _userManager.FindByEmailAsync(adminEmail) == null)
			{
				var adminUser = new AppUserModel
				{
					UserName = adminEmail,
					Email = adminEmail,
					EmailConfirmed = true
				};

				var result = await _userManager.CreateAsync(adminUser, adminPassword);
				if (result.Succeeded)
				{
					await _userManager.AddToRoleAsync(adminUser, "Admin");
				}
			}
		}
	}

}
