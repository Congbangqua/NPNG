﻿using Microsoft.EntityFrameworkCore;
using WebBanHang.Models;

namespace WebBanHang.Repository
{
	public class SeedData
	{
		public static void SeedingData(DataContext _context)
		{
			_context.Database.Migrate();
			if (!_context.Products.Any())
			{ 
				CategoryModel watch = new CategoryModel { Name = "Watch", Slug = "watch", Description = "Various types of watches", Status = 1 };
				CategoryModel smartwatch = new CategoryModel { Name = "Smartwatch", Slug = "smartwatch", Description = "Smartwatches with various features", Status = 1 };

				BrandModel rolex = new BrandModel { Name = "Rolex", Slug = "rolex", Description = "Luxury watches brand", Status = 1 };
				BrandModel casio = new BrandModel { Name = "Casio", Slug = "casio", Description = "Affordable and reliable watches", Status = 1 };

				_context.Products.AddRange(
					new ProductModel { Name = "Watch", Slug = "watch", Description = "watch is the Best", Image = "1.jpg", Category = watch, Brand = rolex, Price = 30 },
					new ProductModel { Name = "casio", Slug = "casio", Description = "Good smartwatch", Image = "2.jpg", Category = smartwatch, Brand = casio, Price = 30 }
				);
				_context.SaveChanges();
			}

		}
	}
}
	